package org.example;
//package dev.selenium.hello;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class HelloSelenium {
    public static void main(String[] args) {

        // Set the path to the chromedriver executable
        System.setProperty("Webdriver.chrome.driver","/Users/anilkumarprajapati/chromedriver/chromedriver_mac_arm64");

        // Launch Chrome browser
        WebDriver driver = new ChromeDriver();

        // Navigate to google.com
        driver.get("https://google.com");

        // Search for "selenium"
        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("selenium");
        searchBox.sendKeys(Keys.ENTER);

         // Click the Wikipedia link in the search results to open it in a new tab
        WebElement wikipediaLink = driver.findElement(By.partialLinkText("Wikipedia"));
        wikipediaLink.sendKeys(Keys.CONTROL, Keys.RETURN);

        // Switch to the new tab
        String currentWindowHandle = driver.getWindowHandle();
        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(currentWindowHandle)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }

        // Print the title of the Wikipedia page
        System.out.println(driver.getTitle());

        // Quit the browser
        driver.quit();

    }

    }
